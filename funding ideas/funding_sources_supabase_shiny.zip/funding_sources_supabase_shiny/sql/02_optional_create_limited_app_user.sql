-- OPTIONAL: create a limited database user for the Shiny app.
-- Replace the username and password before running.
-- If Supabase restricts role creation in your project/plan, skip this file
-- and use the connection credentials Supabase provides.

-- create role funding_tracker_app login password 'replace-with-long-random-password';

-- grant usage on schema public to funding_tracker_app;
-- grant select, insert, update on public.funding_sources to funding_tracker_app;
-- grant select, insert on public.funding_sources_audit to funding_tracker_app;

-- The app intentionally does not need hard delete privileges.
-- If you later add tables, grant privileges explicitly rather than broadly.
