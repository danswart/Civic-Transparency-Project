-- Funding Sources Tracker schema for Supabase/Postgres
-- Run this in Supabase Dashboard > SQL Editor > New Query > Run.

create extension if not exists pgcrypto;

create table if not exists public.funding_sources (
  id uuid primary key default gen_random_uuid(),
  org_name text not null,
  contact_name text,
  email text,
  phone text,
  street_address text,
  website text,
  focus_area text,
  source_type text,
  source_url text,
  lead_owner text,
  priority text default 'Unknown',
  fit_score integer check (fit_score is null or fit_score between 1 and 5),
  marketing_scheme text,
  typical_grant numeric,
  max_grant numeric,
  deadline date,
  last_contacted date,
  next_action text,
  next_action_date date,
  status text default 'New lead',
  abandoned_reason text,
  notes text,
  created_by text,
  created_at timestamptz not null default now(),
  updated_by text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists funding_sources_status_idx
  on public.funding_sources (status);

create index if not exists funding_sources_deadline_idx
  on public.funding_sources (deadline);

create index if not exists funding_sources_next_action_date_idx
  on public.funding_sources (next_action_date);

create index if not exists funding_sources_deleted_at_idx
  on public.funding_sources (deleted_at);

create table if not exists public.funding_sources_audit (
  audit_id uuid primary key default gen_random_uuid(),
  row_id uuid references public.funding_sources(id) on delete set null,
  org_name text,
  action text not null,
  changed_by text,
  field_name text,
  old_value text,
  new_value text,
  changed_at timestamptz not null default now()
);

create index if not exists funding_sources_audit_row_id_idx
  on public.funding_sources_audit (row_id);

create index if not exists funding_sources_audit_changed_at_idx
  on public.funding_sources_audit (changed_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists funding_sources_set_updated_at on public.funding_sources;

create trigger funding_sources_set_updated_at
before update on public.funding_sources
for each row
execute function public.set_updated_at();

-- For this Shiny app, Row Level Security is intentionally left off because
-- the app connects server-side using database credentials and controls access
-- in the Shiny layer. If you later expose Supabase directly to browsers or JS,
-- revisit RLS before going public.
