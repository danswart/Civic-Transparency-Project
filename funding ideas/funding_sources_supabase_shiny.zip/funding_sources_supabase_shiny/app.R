# Funding Sources Tracker — Shiny + Supabase Postgres
# Run locally with: shiny::runApp()

source("R/config.R")
source("R/auth.R")
source("R/db.R")
source("R/repository.R")
source("R/ui.R")
source("R/server.R")

app_config <- get_app_config()

ui <- build_ui(app_config)
server <- build_server(app_config)

shiny::shinyApp(ui = ui, server = server)
