# Funding Sources Tracker — Shiny + Supabase/Postgres

A small shared Shiny app for tracking possible funding sources for a civic transparency AI/RAG project.

The app stores records in Supabase/Postgres, not in a local `.rds` file.

## Quick start

1. Create a Supabase project.
2. Run `sql/01_create_schema.sql` in Supabase SQL Editor.
3. Copy `.Renviron.template` to `.Renviron` and fill in the database settings.
4. Restart R.
5. Run `source("packages.R")`.
6. Run `source("scripts/test_db_connection.R")`.
7. Run `shiny::runApp()`.

See `docs/SETUP_GUIDE.qmd` for full setup instructions.

## Deployment

Use `scripts/deploy_shinyapps.R` after configuring `rsconnect`.

Important: keep `.Renviron` out of GitHub. If deploying to shinyapps.io, read the caution in the setup guide about secret handling.
