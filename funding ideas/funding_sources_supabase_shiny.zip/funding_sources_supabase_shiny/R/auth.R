# Lightweight app gate --------------------------------------------------------
# This is convenience protection for a two-person app, not enterprise security.

auth_panel <- function(config) {
  shiny::fluidPage(
    theme = bslib::bs_theme(bootswatch = "flatly"),
    tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "styles.css")),
    div(
      class = "login-card",
      h2(config$app_title),
      p(config$app_subtitle),
      shiny::textInput("login_user", "Your name", value = config$default_user),
      shiny::passwordInput("login_password", "Shared password"),
      shiny::actionButton("login_button", "Open tracker", class = "btn-primary", width = "100%"),
      br(), br(),
      shiny::uiOutput("login_message"),
      tags$hr(),
      tags$p(
        class = "small-note",
        "This simple gate is intended only to keep casual visitors out of a small private workflow."
      )
    )
  )
}

check_login <- function(input, config) {
  if (!isTRUE(config$require_login)) return(TRUE)
  identical(input$login_password, config$shared_password)
}
