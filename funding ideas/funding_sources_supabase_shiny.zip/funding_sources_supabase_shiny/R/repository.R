# Funding-source repository functions ----------------------------------------

empty_funding_sources <- function() {
  data.frame(
    id = character(), org_name = character(), status = character(), priority = character(),
    fit_score = integer(), focus_area = character(), source_type = character(),
    source_url = character(), website = character(), street_address = character(), lead_owner = character(),
    contact_name = character(), email = character(), phone = character(),
    typical_grant = numeric(), max_grant = numeric(), deadline = as.Date(character()),
    next_action = character(), next_action_date = as.Date(character()),
    last_contacted = as.Date(character()), abandoned_reason = character(),
    marketing_scheme = character(), notes = character(), created_by = character(),
    created_at = as.POSIXct(character()), updated_by = character(),
    updated_at = as.POSIXct(character()), deleted_at = as.POSIXct(character()),
    stringsAsFactors = FALSE
  )
}

sql_na <- function(x) {
  if (length(x) == 0 || is.null(x)) return(NA)
  if (inherits(x, "Date") && is.na(x)) return(NA)
  if (is.atomic(x) && length(x) == 1 && is.na(x)) return(NA)
  if (is.character(x) && identical(x, "")) return(NA_character_)
  x
}

normalize_url <- function(x) {
  x <- trimws(as.character(sql_na(x)))
  if (is.na(x) || x == "") return(NA_character_)
  if (!grepl("^https?://", x, ignore.case = TRUE)) paste0("https://", x) else x
}

coerce_int <- function(x) {
  if (length(x) == 0 || is.null(x) || is.na(x) || identical(x, "")) return(NA_integer_)
  as.integer(x)
}

coerce_num <- function(x) {
  if (length(x) == 0 || is.null(x) || is.na(x) || identical(x, "")) return(NA_real_)
  as.numeric(x)
}

coerce_date <- function(x) {
  if (length(x) == 0 || is.null(x) || identical(as.character(x), "") || is.na(x)) return(as.Date(NA))
  as.Date(x)
}

repo_list_funders <- function(pool, include_deleted = FALSE) {
  where_clause <- if (isTRUE(include_deleted)) "" else "where deleted_at is null"
  sql <- paste(
    "select id::text, org_name, status, priority, fit_score, focus_area, source_type,",
    "source_url, website, street_address, lead_owner, contact_name, email, phone,",
    "typical_grant, max_grant, deadline, next_action, next_action_date,",
    "last_contacted, abandoned_reason, marketing_scheme, notes, created_by,",
    "created_at, updated_by, updated_at, deleted_at",
    "from public.funding_sources",
    where_clause,
    "order by coalesce(next_action_date, deadline) nulls last, updated_at desc"
  )
  out <- DBI::dbGetQuery(pool, sql)
  if (nrow(out) == 0) return(empty_funding_sources())
  out
}

repo_upcoming_deadlines <- function(pool, days = 90) {
  DBI::dbGetQuery(
    pool,
    "select id::text, org_name, deadline, (deadline - current_date)::int as days_until,
            status, priority, lead_owner, contact_name, email, source_url
       from public.funding_sources
      where deleted_at is null
        and deadline is not null
        and deadline >= current_date
        and deadline <= current_date + ($1::int * interval '1 day')
      order by deadline asc, org_name asc;",
    params = list(as.integer(days))
  )
}

repo_recent_activity <- function(pool, limit = 100) {
  DBI::dbGetQuery(
    pool,
    "select audit_id::text, changed_at, changed_by, action, row_id::text,
            org_name, field_name, old_value, new_value
       from public.funding_sources_audit
      order by changed_at desc
      limit $1;",
    params = list(as.integer(limit))
  )
}

repo_create_funder <- function(pool, values, user) {
  values$source_url <- normalize_url(values$source_url)
  values$website <- normalize_url(values$website)

  sql <- "insert into public.funding_sources
    (org_name, contact_name, email, phone, street_address, website,
     focus_area, source_type, source_url, lead_owner, priority, fit_score,
     marketing_scheme, typical_grant, max_grant, deadline, last_contacted,
     next_action, next_action_date, status, abandoned_reason, notes,
     created_by, updated_by)
   values
    ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$23)
   returning id::text;"

  DBI::dbGetQuery(pool, sql, params = list(
    sql_na(values$org_name), sql_na(values$contact_name), sql_na(values$email),
    sql_na(values$phone), sql_na(values$street_address), sql_na(values$website),
    sql_na(values$focus_area), sql_na(values$source_type), sql_na(values$source_url),
    sql_na(values$lead_owner), sql_na(values$priority), coerce_int(values$fit_score),
    sql_na(values$marketing_scheme), coerce_num(values$typical_grant), coerce_num(values$max_grant),
    coerce_date(values$deadline), coerce_date(values$last_contacted), sql_na(values$next_action),
    coerce_date(values$next_action_date), sql_na(values$status), sql_na(values$abandoned_reason),
    sql_na(values$notes), sql_na(user)
  ))
}

repo_update_funder <- function(pool, id, values, user) {
  values$source_url <- normalize_url(values$source_url)
  values$website <- normalize_url(values$website)

  sql <- "update public.funding_sources set
      org_name = $2,
      contact_name = $3,
      email = $4,
      phone = $5,
      street_address = $6,
      website = $7,
      focus_area = $8,
      source_type = $9,
      source_url = $10,
      lead_owner = $11,
      priority = $12,
      fit_score = $13,
      marketing_scheme = $14,
      typical_grant = $15,
      max_grant = $16,
      deadline = $17,
      last_contacted = $18,
      next_action = $19,
      next_action_date = $20,
      status = $21,
      abandoned_reason = $22,
      notes = $23,
      updated_by = $24
    where id = $1::uuid and deleted_at is null;"

  DBI::dbExecute(pool, sql, params = list(
    id, sql_na(values$org_name), sql_na(values$contact_name), sql_na(values$email),
    sql_na(values$phone), sql_na(values$street_address), sql_na(values$website),
    sql_na(values$focus_area), sql_na(values$source_type), sql_na(values$source_url),
    sql_na(values$lead_owner), sql_na(values$priority), coerce_int(values$fit_score),
    sql_na(values$marketing_scheme), coerce_num(values$typical_grant), coerce_num(values$max_grant),
    coerce_date(values$deadline), coerce_date(values$last_contacted), sql_na(values$next_action),
    coerce_date(values$next_action_date), sql_na(values$status), sql_na(values$abandoned_reason),
    sql_na(values$notes), sql_na(user)
  ))
}

repo_soft_delete_funder <- function(pool, id, user, reason = NULL) {
  DBI::dbExecute(
    pool,
    "update public.funding_sources
        set deleted_at = now(), updated_by = $2,
            status = 'Abandoned',
            abandoned_reason = coalesce(nullif($3, ''), abandoned_reason, 'Soft-deleted from app')
      where id = $1::uuid and deleted_at is null;",
    params = list(id, sql_na(user), sql_na(reason))
  )
}

repo_restore_funder <- function(pool, id, user) {
  DBI::dbExecute(
    pool,
    "update public.funding_sources
        set deleted_at = null, updated_by = $2
      where id = $1::uuid;",
    params = list(id, sql_na(user))
  )
}

repo_log_event <- function(pool, row_id, org_name, action, user, field_name = NA, old_value = NA, new_value = NA) {
  DBI::dbExecute(
    pool,
    "insert into public.funding_sources_audit
       (row_id, org_name, action, changed_by, field_name, old_value, new_value)
     values ($1::uuid, $2, $3, $4, $5, $6, $7);",
    params = list(row_id, sql_na(org_name), sql_na(action), sql_na(user), sql_na(field_name), sql_na(old_value), sql_na(new_value))
  )
}
