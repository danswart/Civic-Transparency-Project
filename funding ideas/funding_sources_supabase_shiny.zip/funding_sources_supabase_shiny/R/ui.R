# User interface --------------------------------------------------------------

build_ui <- function(config) {
  shiny::fluidPage(
    theme = bslib::bs_theme(bootswatch = "flatly"),
    tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "styles.css")),
    shiny::uiOutput("app_screen")
  )
}

main_app_ui <- function(config) {
  shiny::tagList(
    div(
      class = "app-header",
      div(
        h1(config$app_title),
        p(config$app_subtitle)
      ),
      div(
        class = "header-actions",
        shiny::uiOutput("current_user"),
        shiny::actionButton("refresh", "Refresh from database", class = "btn-outline-primary")
      )
    ),
    shiny::tabsetPanel(
      id = "main_tabs",
      shiny::tabPanel(
        "Add / Edit",
        br(),
        shiny::fluidRow(
          shiny::column(
            width = 4,
            shiny::wellPanel(
              h4("Funding source record"),
              shiny::uiOutput("selected_record_note"),
              shiny::textInput("org_name", "Organization name *"),
              shiny::selectInput("status", "Status", choices = statuses, selected = "New lead"),
              shiny::selectInput("priority", "Priority", choices = priorities, selected = "Unknown"),
              shiny::sliderInput("fit_score", "Fit score", min = 1, max = 5, value = 3, step = 1),
              shiny::selectInput("focus_area", "Focus area", choices = c("", focus_areas), selected = ""),
              shiny::selectInput("source_type", "Source type", choices = c("", source_types), selected = ""),
              shiny::textInput("source_url", "Source URL"),
              shiny::textInput("website", "Organization website"),
              shiny::textInput("lead_owner", "Lead owner"),
              shiny::hr(),
              shiny::textInput("contact_name", "Contact name"),
              shiny::textInput("email", "Email"),
              shiny::textInput("phone", "Phone"),
              shiny::textAreaInput("street_address", "Street address", rows = 2, resize = "vertical"),
              shiny::hr(),
              shiny::numericInput("typical_grant", "Typical grant ($)", value = NA, min = 0, step = 1000),
              shiny::numericInput("max_grant", "Max grant ($)", value = NA, min = 0, step = 1000),
              shiny::dateInput("deadline", "Application deadline", value = NA, format = "yyyy-mm-dd"),
              shiny::dateInput("last_contacted", "Last contacted", value = NA, format = "yyyy-mm-dd"),
              shiny::textInput("next_action", "Next action"),
              shiny::dateInput("next_action_date", "Next action date", value = NA, format = "yyyy-mm-dd"),
              shiny::textAreaInput("marketing_scheme", "Marketing / funding scheme", rows = 3, resize = "vertical"),
              shiny::textAreaInput("notes", "Notes", rows = 4, resize = "vertical"),
              shiny::textAreaInput("abandoned_reason", "Abandoned reason", rows = 2, resize = "vertical"),
              shiny::fluidRow(
                shiny::column(6, shiny::actionButton("new_record", "New / clear", width = "100%")),
                shiny::column(6, shiny::actionButton("save_record", "Save record", class = "btn-primary", width = "100%"))
              ),
              br(),
              shiny::actionButton("delete_record", "Mark selected record abandoned", class = "btn-warning", width = "100%")
            )
          ),
          shiny::column(
            width = 8,
            shiny::uiOutput("status_message"),
            h4("Funding sources"),
            p(class = "small-note", "Select a row to load it into the form. Use filters and search to review records."),
            DT::DTOutput("funders_table")
          )
        )
      ),
      shiny::tabPanel(
        "Upcoming deadlines",
        br(),
        p("Deadlines within the next 90 days, sorted soonest first."),
        DT::DTOutput("upcoming_table")
      ),
      shiny::tabPanel(
        "Abandoned / closed",
        br(),
        shiny::checkboxInput("show_deleted", "Include soft-deleted records", value = FALSE),
        DT::DTOutput("inactive_table")
      ),
      shiny::tabPanel(
        "Activity log",
        br(),
        p("Recent app-level changes. This is intentionally simple, but it gives you a shared memory trail."),
        DT::DTOutput("activity_table")
      ),
      shiny::tabPanel(
        "Export",
        br(),
        shiny::fluidRow(
          shiny::column(4, shiny::downloadButton("download_csv", "Download active records as CSV", width = "100%")),
          shiny::column(4, shiny::downloadButton("download_all_csv", "Download all records as CSV", width = "100%")),
          shiny::column(4, shiny::downloadButton("download_audit_csv", "Download activity log as CSV", width = "100%"))
        ),
        br(),
        p(class = "small-note", "Exports are generated directly from Supabase/Postgres at the time you click the button.")
      )
    )
  )
}
