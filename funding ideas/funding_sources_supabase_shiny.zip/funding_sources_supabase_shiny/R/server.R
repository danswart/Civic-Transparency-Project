# Server logic ----------------------------------------------------------------

build_server <- function(config) {
  force(config)

  function(input, output, session) {
    authed <- shiny::reactiveVal(!isTRUE(config$require_login))
    current_user <- shiny::reactiveVal(config$default_user)
    pool <- NULL
    selected_id <- shiny::reactiveVal(NULL)
    funders_data <- shiny::reactiveVal(empty_funding_sources())
    status_text <- shiny::reactiveVal("Not connected yet.")

    connect_and_load <- function() {
      if (is.null(pool)) {
        pool <<- make_db_pool(config)
        session$onSessionEnded(function() close_db_pool(pool))
      }
      funders_data(repo_list_funders(pool, include_deleted = FALSE))
      status_text(paste0("Loaded from Supabase/Postgres at ", format(Sys.time(), "%H:%M:%S"), "."))
    }

    output$app_screen <- shiny::renderUI({
      if (!isTRUE(authed())) auth_panel(config) else main_app_ui(config)
    })

    output$login_message <- shiny::renderUI({ NULL })

    shiny::observeEvent(input$login_button, {
      if (check_login(input, config)) {
        current_user(ifelse(nzchar(input$login_user), input$login_user, config$default_user))
        authed(TRUE)
        shiny::showNotification("Login accepted.", type = "message")
      } else {
        output$login_message <- shiny::renderUI({
          tags$p(class = "login-error", "Password was not accepted.")
        })
      }
    })

    shiny::observeEvent(authed(), {
      if (isTRUE(authed())) {
        tryCatch(
          connect_and_load(),
          error = function(e) status_text(paste("Database connection failed:", conditionMessage(e)))
        )
      }
    }, ignoreInit = FALSE)

    shiny::observeEvent(input$refresh, {
      req(isTRUE(authed()))
      connect_and_load()
    })

    output$current_user <- shiny::renderUI({
      tags$span(class = "current-user", paste("User:", current_user()))
    })

    output$status_message <- shiny::renderUI({
      tags$div(class = "status-box", status_text())
    })

    output$selected_record_note <- shiny::renderUI({
      id <- selected_id()
      if (is.null(id)) {
        tags$p(class = "small-note", "Adding a new record.")
      } else {
        tags$p(class = "small-note", paste("Editing selected record:", substr(id, 1, 8)))
      }
    })

    values_from_form <- function() {
      list(
        org_name = input$org_name,
        contact_name = input$contact_name,
        email = input$email,
        phone = input$phone,
        street_address = input$street_address,
        website = input$website,
        focus_area = input$focus_area,
        source_type = input$source_type,
        source_url = input$source_url,
        lead_owner = input$lead_owner,
        priority = input$priority,
        fit_score = input$fit_score,
        marketing_scheme = input$marketing_scheme,
        typical_grant = input$typical_grant,
        max_grant = input$max_grant,
        deadline = input$deadline,
        last_contacted = input$last_contacted,
        next_action = input$next_action,
        next_action_date = input$next_action_date,
        status = input$status,
        abandoned_reason = input$abandoned_reason,
        notes = input$notes
      )
    }

    clear_form <- function() {
      selected_id(NULL)
      shiny::updateTextInput(session, "org_name", value = "")
      shiny::updateTextInput(session, "contact_name", value = "")
      shiny::updateTextInput(session, "email", value = "")
      shiny::updateTextInput(session, "phone", value = "")
      shiny::updateTextAreaInput(session, "street_address", value = "")
      shiny::updateTextInput(session, "website", value = "")
      shiny::updateSelectInput(session, "focus_area", selected = "")
      shiny::updateSelectInput(session, "source_type", selected = "")
      shiny::updateTextInput(session, "source_url", value = "")
      shiny::updateTextInput(session, "lead_owner", value = "")
      shiny::updateSelectInput(session, "priority", selected = "Unknown")
      shiny::updateSliderInput(session, "fit_score", value = 3)
      shiny::updateTextAreaInput(session, "marketing_scheme", value = "")
      shiny::updateNumericInput(session, "typical_grant", value = NA)
      shiny::updateNumericInput(session, "max_grant", value = NA)
      shiny::updateDateInput(session, "deadline", value = NA)
      shiny::updateDateInput(session, "last_contacted", value = NA)
      shiny::updateTextInput(session, "next_action", value = "")
      shiny::updateDateInput(session, "next_action_date", value = NA)
      shiny::updateSelectInput(session, "status", selected = "New lead")
      shiny::updateTextAreaInput(session, "abandoned_reason", value = "")
      shiny::updateTextAreaInput(session, "notes", value = "")
    }

    load_form <- function(row) {
      selected_id(row$id)
      shiny::updateTextInput(session, "org_name", value = row$org_name %||% "")
      shiny::updateTextInput(session, "contact_name", value = row$contact_name %||% "")
      shiny::updateTextInput(session, "email", value = row$email %||% "")
      shiny::updateTextInput(session, "phone", value = row$phone %||% "")
      shiny::updateTextAreaInput(session, "street_address", value = row$street_address %||% "")
      shiny::updateTextInput(session, "website", value = row$website %||% "")
      shiny::updateSelectInput(session, "focus_area", selected = row$focus_area %||% "")
      shiny::updateSelectInput(session, "source_type", selected = row$source_type %||% "")
      shiny::updateTextInput(session, "source_url", value = row$source_url %||% "")
      shiny::updateTextInput(session, "lead_owner", value = row$lead_owner %||% "")
      shiny::updateSelectInput(session, "priority", selected = row$priority %||% "Unknown")
      shiny::updateSliderInput(session, "fit_score", value = ifelse(is.na(row$fit_score), 3, row$fit_score))
      shiny::updateTextAreaInput(session, "marketing_scheme", value = row$marketing_scheme %||% "")
      shiny::updateNumericInput(session, "typical_grant", value = ifelse(is.na(row$typical_grant), NA, row$typical_grant))
      shiny::updateNumericInput(session, "max_grant", value = ifelse(is.na(row$max_grant), NA, row$max_grant))
      shiny::updateDateInput(session, "deadline", value = row$deadline)
      shiny::updateDateInput(session, "last_contacted", value = row$last_contacted)
      shiny::updateTextInput(session, "next_action", value = row$next_action %||% "")
      shiny::updateDateInput(session, "next_action_date", value = row$next_action_date)
      shiny::updateSelectInput(session, "status", selected = row$status %||% "New lead")
      shiny::updateTextAreaInput(session, "abandoned_reason", value = row$abandoned_reason %||% "")
      shiny::updateTextAreaInput(session, "notes", value = row$notes %||% "")
    }

    `%||%` <- function(x, y) {
      if (length(x) == 0 || is.null(x) || (length(x) == 1 && is.na(x))) y else x
    }

    table_display <- function(df) {
      if (nrow(df) == 0) return(df)
      keep <- c(
        "id", "org_name", "status", "priority", "fit_score", "focus_area", "source_type",
        "deadline", "next_action", "next_action_date", "lead_owner", "source_url",
        "typical_grant", "max_grant", "updated_at"
      )
      df[, intersect(keep, names(df)), drop = FALSE]
    }

    output$funders_table <- DT::renderDT({
      df <- table_display(funders_data())
      DT::datatable(
        df,
        rownames = FALSE,
        selection = "single",
        filter = "top",
        extensions = "Buttons",
        options = list(
          pageLength = 15,
          scrollX = TRUE,
          dom = "Bfrtip",
          buttons = c("copy", "csv"),
          columnDefs = list(list(visible = FALSE, targets = 0))
        )
      )
    })

    shiny::observeEvent(input$funders_table_rows_selected, {
      idx <- input$funders_table_rows_selected
      if (length(idx) != 1) return(NULL)
      df <- funders_data()
      if (nrow(df) >= idx) load_form(df[idx, , drop = FALSE])
    })

    shiny::observeEvent(input$new_record, {
      clear_form()
      status_text("Form cleared. Ready for a new record.")
    })

    shiny::observeEvent(input$save_record, {
      req(isTRUE(authed()))
      values <- values_from_form()
      if (!nzchar(trimws(values$org_name))) {
        status_text("Cannot save: Organization name is required.")
        return(NULL)
      }
      if (identical(values$status, "Abandoned") && !nzchar(trimws(values$abandoned_reason))) {
        status_text("Caution: status is Abandoned, but abandoned reason is blank. Save again after adding a reason if possible.")
      }
      tryCatch({
        id <- selected_id()
        if (is.null(id)) {
          created <- repo_create_funder(pool, values, current_user())
          new_id <- created$id[1]
          repo_log_event(pool, new_id, values$org_name, "created", current_user())
          status_text(paste0("Created record for '", values$org_name, "'."))
          selected_id(new_id)
        } else {
          repo_update_funder(pool, id, values, current_user())
          repo_log_event(pool, id, values$org_name, "updated", current_user())
          status_text(paste0("Updated record for '", values$org_name, "'."))
        }
        funders_data(repo_list_funders(pool, include_deleted = FALSE))
      }, error = function(e) {
        status_text(paste("Save failed:", conditionMessage(e)))
      })
    })

    shiny::observeEvent(input$delete_record, {
      req(isTRUE(authed()))
      id <- selected_id()
      if (is.null(id)) {
        status_text("No selected record to abandon.")
        return(NULL)
      }
      values <- values_from_form()
      tryCatch({
        repo_soft_delete_funder(pool, id, current_user(), values$abandoned_reason)
        repo_log_event(pool, id, values$org_name, "soft_deleted", current_user(), "abandoned_reason", NA, values$abandoned_reason)
        funders_data(repo_list_funders(pool, include_deleted = FALSE))
        clear_form()
        status_text("Selected record was marked Abandoned and hidden from the active list.")
      }, error = function(e) status_text(paste("Abandon action failed:", conditionMessage(e))))
    })

    output$upcoming_table <- DT::renderDT({
      req(isTRUE(authed()), !is.null(pool))
      df <- repo_upcoming_deadlines(pool, 90)
      DT::datatable(df, rownames = FALSE, filter = "top", options = list(pageLength = 25, scrollX = TRUE))
    })

    output$inactive_table <- DT::renderDT({
      req(isTRUE(authed()), !is.null(pool))
      df <- repo_list_funders(pool, include_deleted = TRUE)
      inactive <- df[df$status %in% c("Abandoned", "Closed", "Declined") | !is.na(df$deleted_at), , drop = FALSE]
      DT::datatable(inactive, rownames = FALSE, filter = "top", options = list(pageLength = 25, scrollX = TRUE))
    })

    output$activity_table <- DT::renderDT({
      req(isTRUE(authed()), !is.null(pool))
      df <- repo_recent_activity(pool, 200)
      DT::datatable(df, rownames = FALSE, filter = "top", options = list(pageLength = 25, scrollX = TRUE))
    })

    output$download_csv <- shiny::downloadHandler(
      filename = function() paste0("funding_sources_active_", format(Sys.Date(), "%Y%m%d"), ".csv"),
      content = function(file) utils::write.csv(repo_list_funders(pool, FALSE), file, row.names = FALSE, na = "")
    )

    output$download_all_csv <- shiny::downloadHandler(
      filename = function() paste0("funding_sources_all_", format(Sys.Date(), "%Y%m%d"), ".csv"),
      content = function(file) utils::write.csv(repo_list_funders(pool, TRUE), file, row.names = FALSE, na = "")
    )

    output$download_audit_csv <- shiny::downloadHandler(
      filename = function() paste0("funding_sources_activity_", format(Sys.Date(), "%Y%m%d"), ".csv"),
      content = function(file) utils::write.csv(repo_recent_activity(pool, 10000), file, row.names = FALSE, na = "")
    )
  }
}
