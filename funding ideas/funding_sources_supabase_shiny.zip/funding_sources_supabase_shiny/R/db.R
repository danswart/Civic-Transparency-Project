# Database connection ---------------------------------------------------------

make_db_pool <- function(config) {
  validate_config(config)
  pool::dbPool(
    drv = RPostgres::Postgres(),
    host = config$db_host,
    port = config$db_port,
    dbname = config$db_name,
    user = config$db_user,
    password = config$db_password,
    sslmode = config$db_sslmode,
    minSize = config$db_pool_min,
    maxSize = config$db_pool_max,
    idleTimeout = 60
  )
}

check_db_connection <- function(pool) {
  DBI::dbGetQuery(pool, "select now() as database_time;")
}

close_db_pool <- function(pool) {
  if (!is.null(pool)) pool::poolClose(pool)
}
