# Application configuration ---------------------------------------------------

required_packages <- c(
  "shiny", "bslib", "DT", "DBI", "pool", "RPostgres", "glue", "htmltools"
)

missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    "\nInstall them with: install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "), "))",
    call. = FALSE
  )
}

get_env <- function(name, default = "") {
  value <- Sys.getenv(name, unset = default)
  if (identical(value, "")) default else value
}

get_bool_env <- function(name, default = FALSE) {
  value <- tolower(get_env(name, if (isTRUE(default)) "true" else "false"))
  value %in% c("1", "true", "yes", "y")
}

get_app_config <- function() {
  list(
    app_title = get_env("APP_TITLE", "Funding Sources Tracker"),
    app_subtitle = get_env(
      "APP_SUBTITLE",
      "Shared funding-lead tracker for the civic transparency AI project"
    ),
    require_login = get_bool_env("APP_REQUIRE_LOGIN", TRUE),
    shared_password = get_env("APP_SHARED_PASSWORD", ""),
    default_user = get_env("APP_DEFAULT_USER", "Dan"),
    db_host = get_env("SUPABASE_DB_HOST"),
    db_port = as.integer(get_env("SUPABASE_DB_PORT", "5432")),
    db_name = get_env("SUPABASE_DB_NAME", "postgres"),
    db_user = get_env("SUPABASE_DB_USER"),
    db_password = get_env("SUPABASE_DB_PASSWORD"),
    db_sslmode = get_env("SUPABASE_DB_SSLMODE", "require"),
    db_pool_min = as.integer(get_env("DB_POOL_MIN", "0")),
    db_pool_max = as.integer(get_env("DB_POOL_MAX", "5"))
  )
}

validate_config <- function(config) {
  missing <- character()
  for (nm in c("db_host", "db_user", "db_password")) {
    if (is.null(config[[nm]]) || identical(config[[nm]], "")) missing <- c(missing, nm)
  }
  if (length(missing) > 0) {
    stop(
      "Missing database settings: ", paste(missing, collapse = ", "),
      "\nFill in .Renviron using .Renviron.template, restart R, and try again.",
      call. = FALSE
    )
  }
  if (isTRUE(config$require_login) && identical(config$shared_password, "")) {
    stop(
      "APP_REQUIRE_LOGIN is true, but APP_SHARED_PASSWORD is empty. ",
      "Set APP_SHARED_PASSWORD in .Renviron or set APP_REQUIRE_LOGIN=false for local testing.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

focus_areas <- c(
  "Civic Engagement", "Government Transparency", "Public Finance",
  "Civic Technology", "Artificial Intelligence", "Education",
  "Research", "Economic Development", "General Operating", "Other"
)

statuses <- c(
  "New lead", "Researching", "Promising", "Needs partner review",
  "Contact planned", "Contacted", "Application possible", "Applied",
  "Awarded", "Declined", "Abandoned", "Closed"
)

priorities <- c("High", "Medium", "Low", "Unknown")

source_types <- c(
  "Website", "YouTube", "Grant database", "Foundation directory",
  "Article / news", "Referral", "Email", "Conference / webinar", "Other"
)
