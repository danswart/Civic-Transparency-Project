# Import your old local funders.rds into Supabase/Postgres.
# Put funders.rds in the project root before running this script.

source("R/config.R")
source("R/db.R")
source("R/repository.R")

legacy_file <- "funders.rds"
if (!file.exists(legacy_file)) {
  stop("No funders.rds found in the project root.", call. = FALSE)
}

config <- get_app_config()
pool <- make_db_pool(config)
on.exit(close_db_pool(pool), add = TRUE)

legacy <- readRDS(legacy_file)
if (!is.data.frame(legacy)) stop("funders.rds did not contain a data frame.", call. = FALSE)

map_value <- function(df, name, default = NA) {
  if (name %in% names(df)) df[[name]] else rep(default, nrow(df))
}

import_user <- Sys.getenv("APP_DEFAULT_USER", unset = "legacy_import")

for (i in seq_len(nrow(legacy))) {
  values <- list(
    org_name = map_value(legacy, "org_name")[i],
    contact_name = map_value(legacy, "contact_name")[i],
    email = map_value(legacy, "email")[i],
    phone = map_value(legacy, "phone")[i],
    street_address = map_value(legacy, "street_address")[i],
    website = map_value(legacy, "website")[i],
    focus_area = as.character(map_value(legacy, "focus_area")[i]),
    source_type = NA_character_,
    source_url = NA_character_,
    lead_owner = import_user,
    priority = "Unknown",
    fit_score = 3,
    marketing_scheme = map_value(legacy, "marketing_scheme")[i],
    typical_grant = suppressWarnings(as.numeric(map_value(legacy, "typical_grant")[i])),
    max_grant = suppressWarnings(as.numeric(map_value(legacy, "max_grant")[i])),
    deadline = suppressWarnings(as.Date(map_value(legacy, "deadline")[i])),
    last_contacted = suppressWarnings(as.Date(map_value(legacy, "last_contacted")[i])),
    next_action = NA_character_,
    next_action_date = as.Date(NA),
    status = as.character(map_value(legacy, "status", "New lead")[i]),
    abandoned_reason = NA_character_,
    notes = map_value(legacy, "notes")[i]
  )

  if (is.na(values$org_name) || !nzchar(trimws(values$org_name))) next
  created <- repo_create_funder(pool, values, import_user)
  repo_log_event(pool, created$id[1], values$org_name, "imported_from_rds", import_user)
}

cat("Import complete. Rows attempted:", nrow(legacy), "\n")
