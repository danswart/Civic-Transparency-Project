# Test Supabase/Postgres connection before running the Shiny app.

source("R/config.R")
source("R/db.R")

config <- get_app_config()
pool <- make_db_pool(config)
on.exit(close_db_pool(pool), add = TRUE)

print(check_db_connection(pool))
cat("Connection succeeded.\n")
