# Deploy to shinyapps.io.
# Important: shinyapps.io does not provide robust encrypted app-level secret
# management like Posit Connect Cloud. See docs/SETUP_GUIDE.qmd before using.

# One-time setup from your shinyapps.io dashboard:
# rsconnect::setAccountInfo(
#   name   = "YOUR_ACCOUNT_NAME",
#   token  = "YOUR_TOKEN",
#   secret = "YOUR_SECRET"
# )

required_files <- c(
  "app.R",
  "R/config.R",
  "R/auth.R",
  "R/db.R",
  "R/repository.R",
  "R/ui.R",
  "R/server.R",
  "www/styles.css"
)

missing <- required_files[!file.exists(required_files)]
if (length(missing) > 0) stop("Missing files: ", paste(missing, collapse = ", "), call. = FALSE)

# For shinyapps.io, you may need to include a real .Renviron in the deployment
# bundle so Sys.getenv() can read the database settings. This is convenient but
# not ideal secret management. Do not commit .Renviron to GitHub.
app_files <- required_files
if (file.exists(".Renviron")) {
  app_files <- c(app_files, ".Renviron")
} else {
  warning("No .Renviron file found. The deployed app will not have database credentials unless you provide them another way.")
}

rsconnect::deployApp(
  appDir = getwd(),
  appName = "funding-sources-tracker",
  appFiles = app_files,
  forceUpdate = TRUE
)
