install.packages(c(
  "shiny", "bslib", "DT", "DBI", "pool", "RPostgres", "glue", "htmltools", "rsconnect"
))
